import numpy as np
import scipy


#1st order terms
class WA1:        
    def l1(params,cosmo_functions, zz, t=0,sigma=0):
        k1,Pk,Pkd,Pkdd,d,f,D1 = params
        
        b1 = cosmo_functions.survey.b_1(zz)
        xb1 = cosmo_functions.survey1.b_1(zz)
        
        expr = 4*1j*D1**2*f*(3*Pk + Pkd*k1)*(7*b1*(t - 1) + f*(6*t - 3) + 7*t*xb1)/(35*d*k1)
        
        Erf = scipy.special.erf
        if sigma != 0:
            expr = 3*1j*D1**2*f*(-2*f*sigma*(2*t - 1)*(2*Pk*(sigma**4 + 7*sigma**2 + 30) - Pkd*k1*(2*sigma**2 + 15)) - 2*sigma**3*(2*Pk*(sigma**2 + 3) - 3*Pkd*k1)*(b1*(t - 1) + t*xb1) + np.sqrt(2)*np.sqrt(np.pi)*(-3*f*(2*t - 1)*(2*Pk*(sigma**2 - 10) - Pkd*k1*(sigma**2 - 5)) + sigma**2*(6*Pk + Pkd*k1*(sigma**2 - 3))*(b1*(t - 1) + t*xb1))*Erf(np.sqrt(2)*sigma/2)*np.exp(sigma**2/2))*np.exp(-sigma**2/2)/(d*k1*sigma**7)
        
        return expr
    
    def l3(params,cosmo_functions, zz, t=0,sigma=0):
        k1,Pk,Pkd,Pkdd,d,f,D1 = params
        
        b1 = cosmo_functions.survey.b_1(zz)
        xb1 = cosmo_functions.survey1.b_1(zz)
        
        expr = 4*1j*D1**2*f*(9*b1*(2*Pk - Pkd*k1)*(t - 1) + f*(22*Pk - Pkd*k1)*(2*t - 1) + 9*t*xb1*(2*Pk - Pkd*k1))/(45*d*k1)
        
        Erf = scipy.special.erf
        if sigma != 0:
            expr = -7*1j*D1**2*f*(2*f*sigma*(2*t - 1)*(Pk*(4*sigma**6 + 48*sigma**4 + 370*sigma**2 + 2100) - Pkd*k1*(4*sigma**4 + 55*sigma**2 + 525)) + 2*sigma**3*(2*Pk*(2*sigma**4 + 16*sigma**2 + 75) - Pkd*k1*(sigma**2 + 75))*(b1*(t - 1) + t*xb1) - 3*np.sqrt(2)*np.sqrt(np.pi)*(f*(2*t - 1)*(2*Pk*(3*sigma**4 - 55*sigma**2 + 350) + Pkd*k1*(-3*sigma**4 + 40*sigma**2 - 175)) - sigma**2*(Pk*(6*sigma**2 - 50) + Pkd*k1*(sigma**4 - 8*sigma**2 + 25))*(b1*(t - 1) + t*xb1))*Erf(np.sqrt(2)*sigma/2)*np.exp(sigma**2/2))*np.exp(-sigma**2/2)/(2*d*k1*sigma**9)
            
        return expr
    
    
#1st order terms
class RR1:
    def l1(params,cosmo_functions, zz, t=0,sigma=0):
        k1,Pk,Pkd,Pkdd,d,f,D1 = params
        
        fd,Dd,_,_,bd1,fdd,Ddd,_,_,bdd1 = cosmo_functions.get_derivs(zz,tracer = cosmo_functions.survey)
        fd,Dd,_,_,xbd1,fdd,Ddd,_,_,xbdd1 = cosmo_functions.get_derivs(zz,tracer = cosmo_functions.survey1)
        
        b1 = cosmo_functions.survey.b_1(zz)
        xb1 = cosmo_functions.survey1.b_1(zz)
        
        expr = 1j*D1*(D1*(3*f*fd*(8*Pk + 5*Pkd*k1)*(2*t - 1) + 7*f*(4*Pk + 3*Pkd*k1)*(bd1*t + xbd1*(t - 1)) + 7*t*xb1*(4*Pk*fd + 5*Pkd*bd1*k1 + 3*Pkd*fd*k1)) + Dd*f*(2*t - 1)*(3*f*(8*Pk + 5*Pkd*k1) + 7*xb1*(4*Pk + 3*Pkd*k1)) + 7*b1*(D1*(t - 1)*(4*Pk*fd + 3*Pkd*fd*k1 + 5*Pkd*k1*xbd1) + Dd*(2*t - 1)*(4*Pk*f + 3*Pkd*f*k1 + 5*Pkd*k1*xb1)))/(35*d*k1)
        
        Erf = scipy.special.erf
        if sigma != 0:
            expr = 3*1j*D1*(-2*D1*sigma*(f*(-fd*(2*t - 1)*(Pk*(8*sigma**2 + 60) - Pkd*k1*(sigma**4 + 5*sigma**2 + 15)) + sigma**2*(-6*Pk + Pkd*k1*(sigma**2 + 3))*(bd1*t + xbd1*(t - 1))) + sigma**2*(-b1*(t - 1)*(6*Pk*fd - Pkd*fd*k1*(sigma**2 + 3) - Pkd*k1*sigma**2*xbd1) + t*xb1*(-6*Pk*fd + Pkd*bd1*k1*sigma**2 + Pkd*fd*k1*(sigma**2 + 3)))) + 2*Dd*sigma*(2*t - 1)*(-Pkd*b1*k1*sigma**4*xb1 + f**2*(Pk*(8*sigma**2 + 60) - Pkd*k1*(sigma**4 + 5*sigma**2 + 15)) + f*sigma**2*(6*Pk - Pkd*k1*(sigma**2 + 3))*(b1 + xb1)) + np.sqrt(2)*np.sqrt(np.pi)*(D1*(f*(3*fd*(2*t - 1)*(4*Pk*(sigma**2 - 5) + 5*Pkd*k1) + sigma**2*(2*Pk*(sigma**2 - 3) + 3*Pkd*k1)*(bd1*t + xbd1*(t - 1))) + sigma**2*(b1*(t - 1)*(2*Pk*fd*(sigma**2 - 3) + 3*Pkd*fd*k1 + Pkd*k1*sigma**2*xbd1) + t*xb1*(2*Pk*fd*(sigma**2 - 3) + Pkd*bd1*k1*sigma**2 + 3*Pkd*fd*k1))) + Dd*(2*t - 1)*(Pkd*b1*k1*sigma**4*xb1 + 3*f**2*(4*Pk*(sigma**2 - 5) + 5*Pkd*k1) + f*sigma**2*(b1 + xb1)*(2*Pk*(sigma**2 - 3) + 3*Pkd*k1)))*Erf(np.sqrt(2)*sigma/2)*np.exp(sigma**2/2))*np.exp(-sigma**2/2)/(2*d*k1*sigma**7)
        
        return expr
    
    def l3(params,cosmo_functions, zz, t=0,sigma=0):
        k1,Pk,Pkd,Pkdd,d,f,D1 = params
        
        b1 = cosmo_functions.survey.b_1(zz)
        xb1 = cosmo_functions.survey1.b_1(zz)
        
        expr = 2*1j*D1*(D1*(-2*f*fd*(2*Pk - 5*Pkd*k1)*(2*t - 1) - 9*f*(2*Pk - Pkd*k1)*(bd1*t + xbd1*(t - 1)) + 9*fd*t*xb1*(-2*Pk + Pkd*k1)) - Dd*f*(2*t - 1)*(4*Pk*f + 18*Pk*xb1 - 10*Pkd*f*k1 - 9*Pkd*k1*xb1) - 9*b1*(2*Pk - Pkd*k1)*(D1*fd*(t - 1) + Dd*f*(2*t - 1)))/(45*d*k1)
        
        Erf = scipy.special.erf
        if sigma != 0:
            expr = -7*1j*D1*(2*sigma*(D1*(f*(-fd*(2*t - 1)*(4*Pk*(4*sigma**4 + 55*sigma**2 + 525) - Pkd*k1*(2*sigma**6 + 20*sigma**4 + 130*sigma**2 + 525)) + sigma**2*(-2*Pk*(sigma**2 + 75) + Pkd*k1*(2*sigma**4 + 16*sigma**2 + 75))*(bd1*t + xbd1*(t - 1))) + sigma**2*(-b1*(t - 1)*(2*Pk*fd*(sigma**2 + 75) - Pkd*fd*k1*(2*sigma**4 + 16*sigma**2 + 75) - Pkd*k1*sigma**2*xbd1*(2*sigma**2 + 15)) + t*xb1*(-2*Pk*fd*(sigma**2 + 75) + Pkd*bd1*k1*sigma**2*(2*sigma**2 + 15) + Pkd*fd*k1*(2*sigma**4 + 16*sigma**2 + 75)))) - Dd*(2*t - 1)*(-Pkd*b1*k1*sigma**4*xb1*(2*sigma**2 + 15) + f**2*(4*Pk*(4*sigma**4 + 55*sigma**2 + 525) - Pkd*k1*(2*sigma**6 + 20*sigma**4 + 130*sigma**2 + 525)) + f*sigma**2*(b1 + xb1)*(2*Pk*(sigma**2 + 75) - Pkd*k1*(2*sigma**4 + 16*sigma**2 + 75)))) + 3*np.sqrt(2)*np.sqrt(np.pi)*(D1*(f*(fd*(2*t - 1)*(4*Pk*(3*sigma**4 - 40*sigma**2 + 175) + 5*Pkd*k1*(3*sigma**2 - 35)) + sigma**2*(2*Pk*(sigma**4 - 8*sigma**2 + 25) + Pkd*k1*(3*sigma**2 - 25))*(bd1*t + xbd1*(t - 1))) + sigma**2*(b1*(t - 1)*(2*Pk*fd*(sigma**4 - 8*sigma**2 + 25) + Pkd*fd*k1*(3*sigma**2 - 25) + Pkd*k1*sigma**2*xbd1*(sigma**2 - 5)) + t*xb1*(2*Pk*fd*(sigma**4 - 8*sigma**2 + 25) + Pkd*bd1*k1*sigma**2*(sigma**2 - 5) + Pkd*fd*k1*(3*sigma**2 - 25)))) + Dd*(2*t - 1)*(Pkd*b1*k1*sigma**4*xb1*(sigma**2 - 5) + f**2*(4*Pk*(3*sigma**4 - 40*sigma**2 + 175) + 5*Pkd*k1*(3*sigma**2 - 35)) + f*sigma**2*(b1 + xb1)*(2*Pk*(sigma**4 - 8*sigma**2 + 25) + Pkd*k1*(3*sigma**2 - 25))))*Erf(np.sqrt(2)*sigma/2)*np.exp(sigma**2/2))*np.exp(-sigma**2/2)/(4*d*k1*sigma**9)
        
        return expr  

    
#########################################################################################################    

#2nd order terms
class WA2:
    def l0(params,cosmo_functions, zz, t=0,sigma=0):
        k1,Pk,Pkd,Pkdd,d,f,D1 = params
        
        b1 = cosmo_functions.survey.b_1(zz)
        xb1 = cosmo_functions.survey1.b_1(zz)
        
        expr = -2*D1**2*f*(7*b1*(3*Pk + k1*(5*Pkd + Pkdd*k1))*(t - 1)**2 + f*(Pk*(18*t**2 - 18*t - 1) + k1*(Pkd*(30*t**2 - 30*t - 11) + Pkdd*k1*(6*t**2 - 6*t - 5))) + 7*t**2*xb1*(3*Pk + k1*(5*Pkd + Pkdd*k1)))/(105*d**2*k1**2)
        
        Erf = scipy.special.erf
        if sigma != 0:
            expr = D1**2*f*(2*f*sigma*(6*Pk*(sigma**4*(10*t**2 - 10*t + 3) + 2*sigma**2*(54*t**2 - 54*t + 17) + 720*t**2 - 720*t + 240) + k1*(-6*Pkd*(sigma**4*(2*t**2 - 2*t + 1) + sigma**2*(30*t**2 - 30*t + 11) + 270*t**2 - 270*t + 90) + Pkdd*k1*(sigma**2*(6*t**2 - 6*t + 5) + 180*t**2 - 180*t + 60))) + 2*sigma**3*(2*Pk*(7*sigma**2 + 48) - k1*(6*Pkd*(sigma**2 + 10) + Pkdd*k1*(sigma**2 - 12)))*(b1*(t - 1)**2 + t**2*xb1) - np.sqrt(2)*np.sqrt(np.pi)*(f*(2*Pk*(sigma**4*(18*t**2 - 18*t + 7) - 6*sigma**2*(66*t**2 - 66*t + 23) + 2160*t**2 - 2160*t + 720) + k1*(-2*Pkd*(4*sigma**4*(3*t**2 - 3*t + 1) - 3*sigma**2*(60*t**2 - 60*t + 19) + 810*t**2 - 810*t + 270) + Pkdd*k1*(sigma**4*(6*t**2 - 6*t + 1) - 3*sigma**2*(18*t**2 - 18*t + 5) + 180*t**2 - 180*t + 60))) + sigma**2*(Pk*(96 - 18*sigma**2) + k1*(2*Pkd*(7*sigma**2 - 30) + Pkdd*k1*(sigma**4 - 5*sigma**2 + 12)))*(b1*(t - 1)**2 + t**2*xb1))*Erf(np.sqrt(2)*sigma/2)*np.exp(sigma**2/2))*np.exp(-sigma**2/2)/(2*d**2*k1**2*sigma**7)
        
        return expr
    
    def l2(params,cosmo_functions, zz, t=0,sigma=0):
        k1,Pk,Pkd,Pkdd,d,f,D1 = params
        
        b1 = cosmo_functions.survey.b_1(zz)
        xb1 = cosmo_functions.survey1.b_1(zz)
        
        expr = 2*D1**2*f*(-11*b1*(6*Pk - k1*(2*Pkd + Pkdd*k1))*(t - 1)**2 + f*(-2*Pk*(54*t**2 - 54*t + 13) + k1*(Pkd*(-12*t**2 + 12*t + 8) + 3*Pkdd*k1*(2*t**2 - 2*t + 1))) + 11*t**2*xb1*(-6*Pk + k1*(2*Pkd + Pkdd*k1)))/(21*d**2*k1**2)
        
        Erf = scipy.special.erf
        if sigma != 0:
            expr = 5*D1**2*f*(2*f*sigma*(6*Pk*(sigma**6*(20*t**2 - 20*t + 6) + 3*sigma**4*(98*t**2 - 98*t + 31) + 30*sigma**2*(78*t**2 - 78*t + 25) + 15120*t**2 - 15120*t + 5040) + k1*(-6*Pkd*(sigma**6*(4*t**2 - 4*t + 2) + 4*sigma**4*(21*t**2 - 21*t + 8) + 15*sigma**2*(48*t**2 - 48*t + 17) + 5670*t**2 - 5670*t + 1890) + Pkdd*k1*(sigma**4*(30*t**2 - 30*t + 13) + 135*sigma**2*(2*t**2 - 2*t + 1) + 3780*t**2 - 3780*t + 1260))) + 2*sigma**3*(2*Pk*(14*sigma**4 + 111*sigma**2 + 720) + k1*(-6*Pkd*(2*sigma**4 + 19*sigma**2 + 150) + Pkdd*k1*(sigma**4 + 3*sigma**2 + 180)))*(b1*(t - 1)**2 + t**2*xb1) + np.sqrt(2)*np.sqrt(np.pi)*(f*(2*Pk*(sigma**6*(18*t**2 - 18*t + 7) - 3*sigma**4*(186*t**2 - 186*t + 67) + 90*sigma**2*(90*t**2 - 90*t + 31) - 45360*t**2 + 45360*t - 15120) + k1*(-2*Pkd*(4*sigma**6*(3*t**2 - 3*t + 1) - 3*sigma**4*(96*t**2 - 96*t + 31) + 45*sigma**2*(78*t**2 - 78*t + 25) - 17010*t**2 + 17010*t - 5670) + Pkdd*k1*(sigma**6*(6*t**2 - 6*t + 1) - 12*sigma**4*(9*t**2 - 9*t + 2) + 15*sigma**2*(66*t**2 - 66*t + 19) - 3780*t**2 + 3780*t - 1260))) + sigma**2*(-6*Pk*(3*sigma**4 - 43*sigma**2 + 240) + k1*(2*Pkd*(7*sigma**4 - 93*sigma**2 + 450) + Pkdd*k1*(sigma**6 - 8*sigma**4 + 57*sigma**2 - 180)))*(b1*(t - 1)**2 + t**2*xb1))*Erf(np.sqrt(2)*sigma/2)*np.exp(sigma**2/2))*np.exp(-sigma**2/2)/(4*d**2*k1**2*sigma**9)
        
        return expr
    
    
class WARR:
    def l0(params,cosmo_functions, zz, t=0,sigma=0):
        k1,Pk,Pkd,Pkdd,d,f,D1 = params
        
        b1 = cosmo_functions.survey.b_1(zz)
        xb1 = cosmo_functions.survey1.b_1(zz)
        
        fd,Dd,_,_,bd1,fdd,Ddd,_,_,bdd1 = cosmo_functions.get_derivs(zz,tracer = cosmo_functions.survey)
        fd,Dd,_,_,xbd1,fdd,Ddd,_,_,xbdd1 = cosmo_functions.get_derivs(zz,tracer = cosmo_functions.survey1)
        
        expr = -4*D1*(3*Pk + k1*(5*Pkd + Pkdd*k1))*(D1*(3*f*fd*(1 - 2*t)**2 + 7*f*t*(bd1 + xbd1)*(t - 1) + 7*fd*t**2*xb1) + Dd*f*(2*t - 1)*(f*(6*t - 3) + 7*t*xb1) + 7*b1*(t - 1)*(D1*fd*(t - 1) + Dd*f*(2*t - 1)))/(105*d**2*k1**2)
        
        Erf = scipy.special.erf
        if sigma != 0:
            expr = -D1*(2*sigma*(D1*(f*(fd*(1 - 2*t)**2*(2*Pk*(sigma**4 + 18*sigma**2 + 180) + k1*(-Pkd*(2*sigma**4 + 15*sigma**2 + 135) + Pkdd*k1*(2*sigma**2 + 15))) + sigma**2*t*(bd1 + xbd1)*(t - 1)*(2*Pk*(sigma**2 + 12) + k1*(-Pkd*(sigma**2 + 15) + 3*Pkdd*k1))) + fd*sigma**2*(2*Pk*(sigma**2 + 12) + k1*(-Pkd*(sigma**2 + 15) + 3*Pkdd*k1))*(b1*(t - 1)**2 + t**2*xb1)) + Dd*f*(2*t - 1)*(f*(2*t - 1)*(2*Pk*(sigma**4 + 18*sigma**2 + 180) + k1*(-Pkd*(2*sigma**4 + 15*sigma**2 + 135) + Pkdd*k1*(2*sigma**2 + 15))) + sigma**2*(2*Pk*(sigma**2 + 12) + k1*(-Pkd*(sigma**2 + 15) + 3*Pkdd*k1))*(b1*(t - 1) + t*xb1))) + np.sqrt(2)*np.sqrt(np.pi)*(D1*(f*(-3*fd*(1 - 2*t)**2*(2*Pk*(sigma**4 - 14*sigma**2 + 60) - k1*(Pkd*(sigma**4 - 10*sigma**2 + 45) + Pkdd*k1*(sigma**2 - 5))) + sigma**2*t*(bd1 + xbd1)*(t - 1)*(6*Pk*(sigma**2 - 4) + k1*(Pkd*(sigma**4 - 4*sigma**2 + 15) + Pkdd*k1*(sigma**2 - 3)))) + fd*sigma**2*(6*Pk*(sigma**2 - 4) + k1*(Pkd*(sigma**4 - 4*sigma**2 + 15) + Pkdd*k1*(sigma**2 - 3)))*(b1*(t - 1)**2 + t**2*xb1)) - Dd*f*(2*t - 1)*(3*f*(2*t - 1)*(2*Pk*(sigma**4 - 14*sigma**2 + 60) - k1*(Pkd*(sigma**4 - 10*sigma**2 + 45) + Pkdd*k1*(sigma**2 - 5))) - sigma**2*(6*Pk*(sigma**2 - 4) + k1*(Pkd*(sigma**4 - 4*sigma**2 + 15) + Pkdd*k1*(sigma**2 - 3)))*(b1*(t - 1) + t*xb1)))*Erf(np.sqrt(2)*sigma/2)*np.exp(sigma**2/2))*np.exp(-sigma**2/2)/(d**2*k1**2*sigma**7)
        
        return expr
    
    def l2(params,cosmo_functions, zz, t=0,sigma=0):
        k1,Pk,Pkd,Pkdd,d,f,D1 = params
        
        b1 = cosmo_functions.survey.b_1(zz)
        xb1 = cosmo_functions.survey1.b_1(zz)
        
        fd,Dd,_,_,bd1,fdd,Ddd,_,_,bdd1 = cosmo_functions.get_derivs(zz,tracer = cosmo_functions.survey)
        fd,Dd,_,_,xbd1,fdd,Ddd,_,_,xbdd1 = cosmo_functions.get_derivs(zz,tracer = cosmo_functions.survey1)
        
        expr = -4*D1*(D1*(f*(fd*(1 - 2*t)**2*(6*Pk + k1*(6*Pkd + Pkdd*k1)) - t*(6*Pk - k1*(2*Pkd + Pkdd*k1))*(bd1 + xbd1)*(t - 1)) + fd*t**2*xb1*(-6*Pk + k1*(2*Pkd + Pkdd*k1))) + Dd*f*(2*t - 1)*(f*(6*Pk + k1*(6*Pkd + Pkdd*k1))*(2*t - 1) + t*xb1*(-6*Pk + k1*(2*Pkd + Pkdd*k1))) - b1*(6*Pk - k1*(2*Pkd + Pkdd*k1))*(t - 1)*(D1*fd*(t - 1) + Dd*f*(2*t - 1)))/(21*d**2*k1**2)
        
        Erf = scipy.special.erf
        if sigma != 0:
            expr = 5*D1*(-2*sigma*(D1*(f*(fd*(1 - 2*t)**2*(2*Pk*(2*sigma**6 + 51*sigma**4 + 450*sigma**2 + 3780) + k1*(-Pkd*(4*sigma**6 + 51*sigma**4 + 360*sigma**2 + 2835) + Pkdd*k1*(4*sigma**4 + 45*sigma**2 + 315))) + sigma**2*t*(bd1 + xbd1)*(t - 1)*(Pk*(4*sigma**4 + 42*sigma**2 + 360) + k1*(-Pkd*(5*sigma**4 + 24*sigma**2 + 225) + 3*Pkdd*k1*(sigma**2 + 15)))) + fd*sigma**2*(Pk*(4*sigma**4 + 42*sigma**2 + 360) + k1*(-Pkd*(5*sigma**4 + 24*sigma**2 + 225) + 3*Pkdd*k1*(sigma**2 + 15)))*(b1*(t - 1)**2 + t**2*xb1)) + Dd*f*(2*t - 1)*(f*(2*t - 1)*(2*Pk*(2*sigma**6 + 51*sigma**4 + 450*sigma**2 + 3780) + k1*(-Pkd*(4*sigma**6 + 51*sigma**4 + 360*sigma**2 + 2835) + Pkdd*k1*(4*sigma**4 + 45*sigma**2 + 315))) + sigma**2*(Pk*(4*sigma**4 + 42*sigma**2 + 360) + k1*(-Pkd*(5*sigma**4 + 24*sigma**2 + 225) + 3*Pkdd*k1*(sigma**2 + 15)))*(b1*(t - 1) + t*xb1))) + np.sqrt(2)*np.sqrt(np.pi)*(D1*(f*(-3*fd*(1 - 2*t)**2*(2*Pk*(sigma**6 - 23*sigma**4 + 270*sigma**2 - 1260) - k1*(Pkd*(sigma**6 - 19*sigma**4 + 195*sigma**2 - 945) + Pkdd*k1*(sigma**4 - 20*sigma**2 + 105))) + sigma**2*t*(bd1 + xbd1)*(t - 1)*(6*Pk*(sigma**4 - 13*sigma**2 + 60) + k1*(Pkd*(sigma**6 - 7*sigma**4 + 51*sigma**2 - 225) + Pkdd*k1*(sigma**4 - 12*sigma**2 + 45)))) + fd*sigma**2*(6*Pk*(sigma**4 - 13*sigma**2 + 60) + k1*(Pkd*(sigma**6 - 7*sigma**4 + 51*sigma**2 - 225) + Pkdd*k1*(sigma**4 - 12*sigma**2 + 45)))*(b1*(t - 1)**2 + t**2*xb1)) - Dd*f*(2*t - 1)*(3*f*(2*t - 1)*(2*Pk*(sigma**6 - 23*sigma**4 + 270*sigma**2 - 1260) - k1*(Pkd*(sigma**6 - 19*sigma**4 + 195*sigma**2 - 945) + Pkdd*k1*(sigma**4 - 20*sigma**2 + 105))) - sigma**2*(6*Pk*(sigma**4 - 13*sigma**2 + 60) + k1*(Pkd*(sigma**6 - 7*sigma**4 + 51*sigma**2 - 225) + Pkdd*k1*(sigma**4 - 12*sigma**2 + 45)))*(b1*(t - 1) + t*xb1)))*Erf(np.sqrt(2)*sigma/2)*np.exp(sigma**2/2))*np.exp(-sigma**2/2)/(2*d**2*k1**2*sigma**9)
        
        return expr
    
class RR2:
    def l0(params,cosmo_functions, zz, t=0,sigma=0):
        k1,Pk,Pkd,Pkdd,d,f,D1 = params
        
        b1 = cosmo_functions.survey.b_1(zz)
        xb1 = cosmo_functions.survey1.b_1(zz)
        
        fd,Dd,_,_,bd1,fdd,Ddd,_,_,bdd1 = cosmo_functions.get_derivs(zz,tracer = cosmo_functions.survey)
        fd,Dd,_,_,xbd1,fdd,Ddd,_,_,xbdd1 = cosmo_functions.get_derivs(zz,tracer = cosmo_functions.survey1)
        
        expr = (D1**2*(f*(7*bd1*t**2*(8*Pk + k1*(10*Pkd + Pkdd*k1)) - 7*bdd1*t**2*(4*Pk + k1*(10*Pkd + 3*Pkdd*k1)) + 3*fd*(16*Pk + k1*(22*Pkd + 3*Pkdd*k1))*(2*t**2 - 2*t + 1) - 3*fdd*(8*Pk + k1*(18*Pkd + 5*Pkdd*k1))*(2*t**2 - 2*t + 1) + 7*(t - 1)**2*(Pk*(8*xbd1 - 4*xbdd1) + k1*(10*Pkd*(xbd1 - xbdd1) + Pkdd*k1*(xbd1 - 3*xbdd1)))) - t*(7*bd1*(2*fd*(4*Pk + k1*(10*Pkd + 3*Pkdd*k1))*(t - 1) + 5*k1*(2*Pkd + Pkdd*k1)*(t*(xb1 + 2*xbd1) - 2*xbd1)) + 6*fd**2*(8*Pk + k1*(18*Pkd + 5*Pkdd*k1))*(t - 1) - 7*fd*(8*Pk*(t*(xb1 - xbd1) + xbd1) + k1*(10*Pkd*(t*xb1 - 2*t*xbd1 + 2*xbd1) + Pkdd*k1*(t*xb1 - 6*t*xbd1 + 6*xbd1))) + 7*t*xb1*(4*Pk*fdd + 5*bdd1*k1*(2*Pkd + Pkdd*k1) + fdd*k1*(10*Pkd + 3*Pkdd*k1)))) + D1*(Dd*(3*f**2*(16*Pk + k1*(22*Pkd + 3*Pkdd*k1))*(2*t**2 - 2*t + 1) - f*(-56*Pk*(xb1*(2*t**2 - 2*t + 1) + xbd1*(-2*t**2 + 3*t - 1)) + 14*bd1*t*(4*Pk + k1*(10*Pkd + 3*Pkdd*k1))*(2*t - 1) + 6*fd*(1 - 2*t)**2*(8*Pk + k1*(18*Pkd + 5*Pkdd*k1)) + 7*k1*(-10*Pkd*(2*t**2*xb1 - 4*t**2*xbd1 - 2*t*xb1 + 6*t*xbd1 + xb1 - 2*xbd1) - Pkdd*k1*xb1*(2*t**2 - 2*t + 1) + 6*Pkdd*k1*xbd1*(2*t**2 - 3*t + 1))) - 14*t*xb1*(2*t - 1)*(4*Pk*fd + 5*bd1*k1*(2*Pkd + Pkdd*k1) + fd*k1*(10*Pkd + 3*Pkdd*k1))) - Ddd*f*(3*f*(8*Pk + k1*(18*Pkd + 5*Pkdd*k1)) + 7*xb1*(4*Pk + k1*(10*Pkd + 3*Pkdd*k1)))*(2*t**2 - 2*t + 1)) - 2*Dd**2*f*t*(t - 1)*(3*f*(8*Pk + k1*(18*Pkd + 5*Pkdd*k1)) + 7*xb1*(4*Pk + k1*(10*Pkd + 3*Pkdd*k1))) + 7*b1*(-D1**2*(t - 1)**2*(-fd*(8*Pk + k1*(10*Pkd + Pkdd*k1)) + fdd*(4*Pk + 10*Pkd*k1 + 3*Pkdd*k1**2) + 5*k1*(2*Pkd + Pkdd*k1)*(xbd1 + xbdd1)) + D1*(Dd*(f*(8*Pk + k1*(10*Pkd + Pkdd*k1))*(2*t**2 - 2*t + 1) - 2*fd*(4*Pk + k1*(10*Pkd + 3*Pkdd*k1))*(2*t**2 - 3*t + 1) - 5*k1*(2*Pkd + Pkdd*k1)*(2*t**2*xb1 + 4*t**2*xbd1 - 2*t*xb1 - 6*t*xbd1 + xb1 + 2*xbd1)) - Ddd*(2*t**2 - 2*t + 1)*(4*Pk*f + f*k1*(10*Pkd + 3*Pkdd*k1) + 5*k1*xb1*(2*Pkd + Pkdd*k1))) - 2*Dd**2*t*(t - 1)*(4*Pk*f + f*k1*(10*Pkd + 3*Pkdd*k1) + 5*k1*xb1*(2*Pkd + Pkdd*k1))))/(210*d**2*k1**2)
        
        Erf = scipy.special.erf
        if sigma != 0:
            expr = (-2*sigma*(D1**2*(b1*sigma**2*(t - 1)**2*(2*Pk*fd*(sigma**2 + 24) + 2*Pk*fdd*(sigma**2 - 12) + 15*Pkd*fdd*k1 - Pkdd*fdd*k1**2*(sigma**2 + 3) + fd*k1*(-2*Pkd*(sigma**2 + 15) + Pkdd*k1*(sigma**2 + 6)) + k1*sigma**2*(-Pkd + Pkdd*k1)*(2*xbd1 - xbdd1)) + f*(fd*(Pk*(8*sigma**4 + 84*sigma**2 + 720) + k1*(-2*Pkd*(sigma**4 + 21*sigma**2 + 135) + Pkdd*k1*(sigma**4 + 7*sigma**2 + 30)))*(2*t**2 - 2*t + 1) - fdd*(12*Pk*(sigma**2 + 30) + k1*(-9*Pkd*(2*sigma**2 + 15) + Pkdd*k1*(sigma**4 + 5*sigma**2 + 15)))*(2*t**2 - 2*t + 1) + sigma**2*(bd1*t**2*(2*Pk*(sigma**2 + 24) + k1*(-2*Pkd*(sigma**2 + 15) + Pkdd*k1*(sigma**2 + 6))) + bdd1*t**2*(2*Pk*(sigma**2 - 12) + 15*Pkd*k1 - Pkdd*k1**2*(sigma**2 + 3)) + (t - 1)**2*(2*Pk*(xbd1*(sigma**2 + 24) + xbdd1*(sigma**2 - 12)) + k1*(-2*Pkd*xbd1*(sigma**2 + 15) + 15*Pkd*xbdd1 + Pkdd*k1*xbd1*(sigma**2 + 6) - Pkdd*k1*xbdd1*(sigma**2 + 3))))) + t*(-2*fd**2*(t - 1)*(12*Pk*(sigma**2 + 30) + k1*(-9*Pkd*(2*sigma**2 + 15) + Pkdd*k1*(sigma**4 + 5*sigma**2 + 15))) + fd*sigma**2*(2*Pk*(t*xb1*(sigma**2 + 24) + 2*t*xbd1*(sigma**2 - 12) - 2*xbd1*(sigma**2 - 12)) + 2*bd1*(t - 1)*(2*Pk*(sigma**2 - 12) + 15*Pkd*k1 - Pkdd*k1**2*(sigma**2 + 3)) + k1*(-2*Pkd*(t*xb1*(sigma**2 + 15) - 15*t*xbd1 + 15*xbd1) + Pkdd*k1*(t*xb1*(sigma**2 + 6) - 2*t*xbd1*(sigma**2 + 3) + 2*xbd1*(sigma**2 + 3)))) + fdd*sigma**2*t*xb1*(2*Pk*(sigma**2 - 12) + 15*Pkd*k1 - Pkdd*k1**2*(sigma**2 + 3)) + k1*sigma**4*(-Pkd + Pkdd*k1)*(2*bd1*(t*(xb1 - xbd1) + xbd1) - bdd1*t*xb1))) + D1*(Dd*(f**2*(Pk*(8*sigma**4 + 84*sigma**2 + 720) + k1*(-2*Pkd*(sigma**4 + 21*sigma**2 + 135) + Pkdd*k1*(sigma**4 + 7*sigma**2 + 30)))*(2*t**2 - 2*t + 1) + f*(-2*fd*(1 - 2*t)**2*(12*Pk*(sigma**2 + 30) + k1*(-9*Pkd*(2*sigma**2 + 15) + Pkdd*k1*(sigma**4 + 5*sigma**2 + 15))) + sigma**2*(4*Pk*sigma**2*t**2*xb1 + 8*Pk*sigma**2*t**2*xbd1 - 4*Pk*sigma**2*t*xb1 - 12*Pk*sigma**2*t*xbd1 + 2*Pk*sigma**2*xb1 + 4*Pk*sigma**2*xbd1 + 96*Pk*t**2*xb1 - 96*Pk*t**2*xbd1 - 96*Pk*t*xb1 + 144*Pk*t*xbd1 + 48*Pk*xb1 - 48*Pk*xbd1 - 4*Pkd*k1*sigma**2*t**2*xb1 + 4*Pkd*k1*sigma**2*t*xb1 - 2*Pkd*k1*sigma**2*xb1 - 60*Pkd*k1*t**2*xb1 + 60*Pkd*k1*t**2*xbd1 + 60*Pkd*k1*t*xb1 - 90*Pkd*k1*t*xbd1 - 30*Pkd*k1*xb1 + 30*Pkd*k1*xbd1 + 2*Pkdd*k1**2*sigma**2*t**2*xb1 - 4*Pkdd*k1**2*sigma**2*t**2*xbd1 - 2*Pkdd*k1**2*sigma**2*t*xb1 + 6*Pkdd*k1**2*sigma**2*t*xbd1 + Pkdd*k1**2*sigma**2*xb1 - 2*Pkdd*k1**2*sigma**2*xbd1 + 12*Pkdd*k1**2*t**2*xb1 - 12*Pkdd*k1**2*t**2*xbd1 - 12*Pkdd*k1**2*t*xb1 + 18*Pkdd*k1**2*t*xbd1 + 6*Pkdd*k1**2*xb1 - 6*Pkdd*k1**2*xbd1 + b1*(2*Pk*(sigma**2 + 24) + k1*(-2*Pkd*(sigma**2 + 15) + Pkdd*k1*(sigma**2 + 6)))*(2*t**2 - 2*t + 1) + 2*bd1*t*(2*t - 1)*(2*Pk*(sigma**2 - 12) + 15*Pkd*k1 - Pkdd*k1**2*(sigma**2 + 3)))) + 2*sigma**2*(b1*(fd*(2*t**2 - 3*t + 1)*(2*Pk*(sigma**2 - 12) + 15*Pkd*k1 - Pkdd*k1**2*(sigma**2 + 3)) + k1*sigma**2*(-Pkd + Pkdd*k1)*(xb1*(2*t**2 - 2*t + 1) + xbd1*(-2*t**2 + 3*t - 1))) + t*xb1*(2*t - 1)*(bd1*k1*sigma**2*(Pkd - Pkdd*k1) + fd*(2*Pk*(sigma**2 - 12) + 15*Pkd*k1 - Pkdd*k1**2*(sigma**2 + 3))))) - Ddd*(2*t**2 - 2*t + 1)*(b1*k1*sigma**4*xb1*(-Pkd + Pkdd*k1) + f**2*(12*Pk*(sigma**2 + 30) + k1*(-9*Pkd*(2*sigma**2 + 15) + Pkdd*k1*(sigma**4 + 5*sigma**2 + 15))) - f*sigma**2*(b1 + xb1)*(2*Pk*(sigma**2 - 12) + 15*Pkd*k1 - Pkdd*k1**2*(sigma**2 + 3)))) - 2*Dd**2*t*(t - 1)*(b1*k1*sigma**4*xb1*(-Pkd + Pkdd*k1) + f**2*(12*Pk*(sigma**2 + 30) + k1*(-9*Pkd*(2*sigma**2 + 15) + Pkdd*k1*(sigma**4 + 5*sigma**2 + 15))) - f*sigma**2*(b1 + xb1)*(2*Pk*(sigma**2 - 12) + 15*Pkd*k1 - Pkdd*k1**2*(sigma**2 + 3)))) + np.sqrt(2)*np.sqrt(np.pi)*(D1**2*(b1*sigma**2*(t - 1)**2*(fd*(2*Pk*(sigma**4 - 7*sigma**2 + 24) + k1*(Pkd*(8*sigma**2 - 30) - Pkdd*k1*(sigma**2 - 6))) - fdd*(2*Pk*(sigma**4 - 5*sigma**2 + 12) + k1*(5*Pkd*(sigma**2 - 3) + 3*Pkdd*k1)) - k1*sigma**2*(Pkd*(2*xbd1 + xbdd1*(sigma**2 - 1)) + Pkdd*k1*(xbd1*(sigma**2 - 2) + xbdd1))) + f*(3*fd*(4*Pk*(sigma**4 - 13*sigma**2 + 60) + k1*(2*Pkd*(8*sigma**2 - 45) - Pkdd*k1*(sigma**2 - 10)))*(2*t**2 - 2*t + 1) - 3*fdd*(4*Pk*(sigma**4 - 9*sigma**2 + 30) + k1*(9*Pkd*(sigma**2 - 5) + 5*Pkdd*k1))*(2*t**2 - 2*t + 1) + sigma**2*(bd1*t**2*(2*Pk*(sigma**4 - 7*sigma**2 + 24) + k1*(Pkd*(8*sigma**2 - 30) - Pkdd*k1*(sigma**2 - 6))) - bdd1*t**2*(2*Pk*(sigma**4 - 5*sigma**2 + 12) + k1*(5*Pkd*(sigma**2 - 3) + 3*Pkdd*k1)) + (t - 1)**2*(2*Pk*(xbd1*(sigma**4 - 7*sigma**2 + 24) - xbdd1*(sigma**4 - 5*sigma**2 + 12)) - k1*(Pkd*xbd1*(30 - 8*sigma**2) + 5*Pkd*xbdd1*(sigma**2 - 3) + Pkdd*k1*xbd1*(sigma**2 - 6) + 3*Pkdd*k1*xbdd1)))) - t*(6*fd**2*(t - 1)*(4*Pk*(sigma**4 - 9*sigma**2 + 30) + k1*(9*Pkd*(sigma**2 - 5) + 5*Pkdd*k1)) + fd*sigma**2*(-2*Pk*(t*xb1*(sigma**4 - 7*sigma**2 + 24) - 2*t*xbd1*(sigma**4 - 5*sigma**2 + 12) + 2*xbd1*(sigma**4 - 5*sigma**2 + 12)) + 2*bd1*(t - 1)*(2*Pk*(sigma**4 - 5*sigma**2 + 12) + k1*(5*Pkd*(sigma**2 - 3) + 3*Pkdd*k1)) + k1*(-2*Pkd*(t*xb1*(4*sigma**2 - 15) - 5*t*xbd1*(sigma**2 - 3) + 5*xbd1*(sigma**2 - 3)) + Pkdd*k1*(t*xb1*(sigma**2 - 6) + 6*t*xbd1 - 6*xbd1))) + fdd*sigma**2*t*xb1*(2*Pk*(sigma**4 - 5*sigma**2 + 12) + k1*(5*Pkd*(sigma**2 - 3) + 3*Pkdd*k1)) + k1*sigma**4*(bd1*(2*Pkd*(-sigma**2*xbd1 + t*(xb1 + xbd1*(sigma**2 - 1)) + xbd1) + Pkdd*k1*(t*xb1*(sigma**2 - 2) + 2*t*xbd1 - 2*xbd1)) + bdd1*t*xb1*(Pkd*(sigma**2 - 1) + Pkdd*k1)))) + D1*(Dd*(3*f**2*(4*Pk*(sigma**4 - 13*sigma**2 + 60) + k1*(2*Pkd*(8*sigma**2 - 45) - Pkdd*k1*(sigma**2 - 10)))*(2*t**2 - 2*t + 1) - f*(6*fd*(1 - 2*t)**2*(4*Pk*(sigma**4 - 9*sigma**2 + 30) + k1*(9*Pkd*(sigma**2 - 5) + 5*Pkdd*k1)) + sigma**2*(-4*Pk*sigma**4*t**2*xb1 + 8*Pk*sigma**4*t**2*xbd1 + 4*Pk*sigma**4*t*xb1 - 12*Pk*sigma**4*t*xbd1 - 2*Pk*sigma**4*xb1 + 4*Pk*sigma**4*xbd1 + 28*Pk*sigma**2*t**2*xb1 - 40*Pk*sigma**2*t**2*xbd1 - 28*Pk*sigma**2*t*xb1 + 60*Pk*sigma**2*t*xbd1 + 14*Pk*sigma**2*xb1 - 20*Pk*sigma**2*xbd1 - 96*Pk*t**2*xb1 + 96*Pk*t**2*xbd1 + 96*Pk*t*xb1 - 144*Pk*t*xbd1 - 48*Pk*xb1 + 48*Pk*xbd1 - 16*Pkd*k1*sigma**2*t**2*xb1 + 20*Pkd*k1*sigma**2*t**2*xbd1 + 16*Pkd*k1*sigma**2*t*xb1 - 30*Pkd*k1*sigma**2*t*xbd1 - 8*Pkd*k1*sigma**2*xb1 + 10*Pkd*k1*sigma**2*xbd1 + 60*Pkd*k1*t**2*xb1 - 60*Pkd*k1*t**2*xbd1 - 60*Pkd*k1*t*xb1 + 90*Pkd*k1*t*xbd1 + 30*Pkd*k1*xb1 - 30*Pkd*k1*xbd1 + 2*Pkdd*k1**2*sigma**2*t**2*xb1 - 2*Pkdd*k1**2*sigma**2*t*xb1 + Pkdd*k1**2*sigma**2*xb1 - 12*Pkdd*k1**2*t**2*xb1 + 12*Pkdd*k1**2*t**2*xbd1 + 12*Pkdd*k1**2*t*xb1 - 18*Pkdd*k1**2*t*xbd1 - 6*Pkdd*k1**2*xb1 + 6*Pkdd*k1**2*xbd1 - b1*(2*Pk*(sigma**4 - 7*sigma**2 + 24) + k1*(Pkd*(8*sigma**2 - 30) - Pkdd*k1*(sigma**2 - 6)))*(2*t**2 - 2*t + 1) + 2*bd1*t*(2*t - 1)*(2*Pk*(sigma**4 - 5*sigma**2 + 12) + k1*(5*Pkd*(sigma**2 - 3) + 3*Pkdd*k1)))) - sigma**2*(b1*(2*fd*(2*Pk*(sigma**4 - 5*sigma**2 + 12) + k1*(5*Pkd*(sigma**2 - 3) + 3*Pkdd*k1))*(2*t**2 - 3*t + 1) + k1*sigma**2*(2*Pkd*(xb1*(2*t**2 - 2*t + 1) + xbd1*(sigma**2 - 1)*(2*t**2 - 3*t + 1)) + Pkdd*k1*(xb1*(sigma**2 - 2)*(2*t**2 - 2*t + 1) + 2*xbd1*(2*t**2 - 3*t + 1)))) + 2*t*xb1*(2*t - 1)*(bd1*k1*sigma**2*(Pkd*(sigma**2 - 1) + Pkdd*k1) + fd*(2*Pk*(sigma**4 - 5*sigma**2 + 12) + k1*(5*Pkd*(sigma**2 - 3) + 3*Pkdd*k1))))) - Ddd*(2*t**2 - 2*t + 1)*(b1*k1*sigma**4*xb1*(Pkd*(sigma**2 - 1) + Pkdd*k1) + 3*f**2*(4*Pk*(sigma**4 - 9*sigma**2 + 30) + k1*(9*Pkd*(sigma**2 - 5) + 5*Pkdd*k1)) + f*sigma**2*(b1 + xb1)*(2*Pk*(sigma**4 - 5*sigma**2 + 12) + k1*(5*Pkd*(sigma**2 - 3) + 3*Pkdd*k1)))) - 2*Dd**2*t*(t - 1)*(b1*k1*sigma**4*xb1*(Pkd*(sigma**2 - 1) + Pkdd*k1) + 3*f**2*(4*Pk*(sigma**4 - 9*sigma**2 + 30) + k1*(9*Pkd*(sigma**2 - 5) + 5*Pkdd*k1)) + f*sigma**2*(b1 + xb1)*(2*Pk*(sigma**4 - 5*sigma**2 + 12) + k1*(5*Pkd*(sigma**2 - 3) + 3*Pkdd*k1))))*Erf(np.sqrt(2)*sigma/2)*np.exp(sigma**2/2))*np.exp(-sigma**2/2)/(4*d**2*k1**2*sigma**7)
        
        return expr
    
    def l2(params,cosmo_functions, zz, t=0,sigma=0):
        k1,Pk,Pkd,Pkdd,d,f,D1 = params
        
        b1 = cosmo_functions.survey.b_1(zz)
        xb1 = cosmo_functions.survey1.b_1(zz)
        
        fd,Dd,_,_,bd1,fdd,Ddd,_,_,bdd1 = cosmo_functions.get_derivs(zz,tracer = cosmo_functions.survey)
        fd,Dd,_,_,xbd1,fdd,Ddd,_,_,xbdd1 = cosmo_functions.get_derivs(zz,tracer = cosmo_functions.survey1)
        
        expr = (D1**2*(f*(-2*Pk*bd1*t**2 + 22*Pk*bdd1*t**2 - 2*Pk*t**2*xbd1 + 22*Pk*t**2*xbdd1 + 4*Pk*t*xbd1 - 44*Pk*t*xbdd1 - 2*Pk*xbd1 + 22*Pk*xbdd1 - 4*Pkd*bd1*k1*t**2 - 5*Pkd*bdd1*k1*t**2 - 4*Pkd*k1*t**2*xbd1 - 5*Pkd*k1*t**2*xbdd1 + 8*Pkd*k1*t*xbd1 + 10*Pkd*k1*t*xbdd1 - 4*Pkd*k1*xbd1 - 5*Pkd*k1*xbdd1 + 5*Pkdd*bd1*k1**2*t**2 - 6*Pkdd*bdd1*k1**2*t**2 + 5*Pkdd*k1**2*t**2*xbd1 - 6*Pkdd*k1**2*t**2*xbdd1 - 10*Pkdd*k1**2*t*xbd1 + 12*Pkdd*k1**2*t*xbdd1 + 5*Pkdd*k1**2*xbd1 - 6*Pkdd*k1**2*xbdd1 + 2*fd*(6*Pk + k1*(3*Pkd + 2*Pkdd*k1))*(2*t**2 - 2*t + 1) + fdd*(12*Pk - 9*Pkd*k1 - 5*Pkdd*k1**2)*(2*t**2 - 2*t + 1)) + t*(2*bd1*(fd*(22*Pk - k1*(5*Pkd + 6*Pkdd*k1))*(t - 1) + 7*k1*(-Pkd + Pkdd*k1)*(t*(xb1 - xbd1) + xbd1)) + 2*fd**2*(12*Pk - k1*(9*Pkd + 5*Pkdd*k1))*(t - 1) + fd*(-2*Pk*(t*(xb1 - 22*xbd1) + 22*xbd1) + k1*(-2*Pkd*(2*t*xb1 + 5*t*xbd1 - 5*xbd1) + Pkdd*k1*(5*t*xb1 - 12*t*xbd1 + 12*xbd1))) + t*xb1*(22*Pk*fdd + 7*bdd1*k1*(Pkd - Pkdd*k1) - fdd*k1*(5*Pkd + 6*Pkdd*k1)))) + D1*(Dd*(2*f**2*(6*Pk + k1*(3*Pkd + 2*Pkdd*k1))*(2*t**2 - 2*t + 1) + f*(-4*Pk*t**2*xb1 + 88*Pk*t**2*xbd1 + 4*Pk*t*xb1 - 132*Pk*t*xbd1 - 2*Pk*xb1 + 44*Pk*xbd1 - 8*Pkd*k1*t**2*xb1 - 20*Pkd*k1*t**2*xbd1 + 8*Pkd*k1*t*xb1 + 30*Pkd*k1*t*xbd1 - 4*Pkd*k1*xb1 - 10*Pkd*k1*xbd1 + 10*Pkdd*k1**2*t**2*xb1 - 24*Pkdd*k1**2*t**2*xbd1 - 10*Pkdd*k1**2*t*xb1 + 36*Pkdd*k1**2*t*xbd1 + 5*Pkdd*k1**2*xb1 - 12*Pkdd*k1**2*xbd1 + 2*bd1*t*(2*t - 1)*(22*Pk - 5*Pkd*k1 - 6*Pkdd*k1**2) + 2*fd*(1 - 2*t)**2*(12*Pk - k1*(9*Pkd + 5*Pkdd*k1))) + 2*t*xb1*(2*t - 1)*(22*Pk*fd + 7*bd1*k1*(Pkd - Pkdd*k1) - fd*k1*(5*Pkd + 6*Pkdd*k1))) + Ddd*f*(2*t**2 - 2*t + 1)*(12*Pk*f + 22*Pk*xb1 - f*k1*(9*Pkd + 5*Pkdd*k1) - k1*xb1*(5*Pkd + 6*Pkdd*k1))) + 2*Dd**2*f*t*(t - 1)*(12*Pk*f + 22*Pk*xb1 - f*k1*(9*Pkd + 5*Pkdd*k1) - k1*xb1*(5*Pkd + 6*Pkdd*k1)) - b1*(D1**2*(t - 1)**2*(2*Pk*fd - 22*Pk*fdd + fd*k1*(4*Pkd - 5*Pkdd*k1) + fdd*k1*(5*Pkd + 6*Pkdd*k1) + 7*k1*(Pkd - Pkdd*k1)*(2*xbd1 - xbdd1)) + D1*(Dd*(f*(2*Pk + k1*(4*Pkd - 5*Pkdd*k1))*(2*t**2 - 2*t + 1) - 2*fd*(22*Pk - k1*(5*Pkd + 6*Pkdd*k1))*(2*t**2 - 3*t + 1) - 14*k1*(-Pkd + Pkdd*k1)*(xb1*(2*t**2 - 2*t + 1) + xbd1*(-2*t**2 + 3*t - 1))) - Ddd*(2*t**2 - 2*t + 1)*(22*Pk*f - f*k1*(5*Pkd + 6*Pkdd*k1) + 7*k1*xb1*(Pkd - Pkdd*k1))) - 2*Dd**2*t*(t - 1)*(22*Pk*f - f*k1*(5*Pkd + 6*Pkdd*k1) + 7*k1*xb1*(Pkd - Pkdd*k1))))/(21*d**2*k1**2)
        
        Erf = scipy.special.erf
        if sigma != 0:
            expr = (-10*sigma*(D1**2*(b1*sigma**2*(t - 1)**2*(fd*(2*Pk*(5*sigma**4 + 33*sigma**2 + 360) + k1*(-2*Pkd*(2*sigma**4 + 24*sigma**2 + 225) + Pkdd*k1*(2*sigma**4 + 15*sigma**2 + 90))) - fdd*(2*Pk*(sigma**4 + 3*sigma**2 + 180) + k1*(-15*Pkd*(sigma**2 + 15) + Pkdd*k1*(2*sigma**4 + 12*sigma**2 + 45))) + k1*sigma**2*(-Pkd*(2*xbd1*(2*sigma**2 + 9) + xbdd1*(sigma**2 - 9)) + Pkdd*k1*(xbd1*(sigma**2 + 18) - xbdd1*(2*sigma**2 + 9)))) + f*(fd*(4*Pk*(4*sigma**6 + 63*sigma**4 + 495*sigma**2 + 3780) + k1*(-2*Pkd*(2*sigma**6 + 48*sigma**4 + 450*sigma**2 + 2835) + Pkdd*k1*(2*sigma**6 + 20*sigma**4 + 135*sigma**2 + 630)))*(2*t**2 - 2*t + 1) - fdd*(60*Pk*(sigma**4 + 9*sigma**2 + 126) + k1*(-9*Pkd*(4*sigma**4 + 45*sigma**2 + 315) + Pkdd*k1*(2*sigma**6 + 16*sigma**4 + 90*sigma**2 + 315)))*(2*t**2 - 2*t + 1) + sigma**2*(bd1*t**2*(2*Pk*(5*sigma**4 + 33*sigma**2 + 360) + k1*(-2*Pkd*(2*sigma**4 + 24*sigma**2 + 225) + Pkdd*k1*(2*sigma**4 + 15*sigma**2 + 90))) - bdd1*t**2*(2*Pk*(sigma**4 + 3*sigma**2 + 180) + k1*(-15*Pkd*(sigma**2 + 15) + Pkdd*k1*(2*sigma**4 + 12*sigma**2 + 45))) + (t - 1)**2*(2*Pk*(xbd1*(5*sigma**4 + 33*sigma**2 + 360) - xbdd1*(sigma**4 + 3*sigma**2 + 180)) + k1*(-2*Pkd*xbd1*(2*sigma**4 + 24*sigma**2 + 225) + 15*Pkd*xbdd1*(sigma**2 + 15) + Pkdd*k1*xbd1*(2*sigma**4 + 15*sigma**2 + 90) - Pkdd*k1*xbdd1*(2*sigma**4 + 12*sigma**2 + 45))))) - t*(2*fd**2*(t - 1)*(60*Pk*(sigma**4 + 9*sigma**2 + 126) + k1*(-9*Pkd*(4*sigma**4 + 45*sigma**2 + 315) + Pkdd*k1*(2*sigma**6 + 16*sigma**4 + 90*sigma**2 + 315))) + fd*sigma**2*(-2*Pk*(t*xb1*(5*sigma**4 + 33*sigma**2 + 360) - 2*t*xbd1*(sigma**4 + 3*sigma**2 + 180) + 2*xbd1*(sigma**4 + 3*sigma**2 + 180)) + 2*bd1*(t - 1)*(2*Pk*(sigma**4 + 3*sigma**2 + 180) + k1*(-15*Pkd*(sigma**2 + 15) + Pkdd*k1*(2*sigma**4 + 12*sigma**2 + 45))) + k1*(Pkd*(t*xb1*(4*sigma**4 + 48*sigma**2 + 450) - 30*t*xbd1*(sigma**2 + 15) + 30*xbd1*(sigma**2 + 15)) - Pkdd*k1*(t*xb1*(2*sigma**4 + 15*sigma**2 + 90) - 2*t*xbd1*(2*sigma**4 + 12*sigma**2 + 45) + 2*xbd1*(2*sigma**4 + 12*sigma**2 + 45)))) + fdd*sigma**2*t*xb1*(2*Pk*(sigma**4 + 3*sigma**2 + 180) + k1*(-15*Pkd*(sigma**2 + 15) + Pkdd*k1*(2*sigma**4 + 12*sigma**2 + 45))) + k1*sigma**4*(bd1*(2*Pkd*(t*xb1*(2*sigma**2 + 9) + t*xbd1*(sigma**2 - 9) - xbd1*(sigma**2 - 9)) - Pkdd*k1*(t*xb1*(sigma**2 + 18) - 2*t*xbd1*(2*sigma**2 + 9) + 2*xbd1*(2*sigma**2 + 9))) + bdd1*t*xb1*(Pkd*(sigma**2 - 9) + Pkdd*k1*(2*sigma**2 + 9))))) + D1*(Dd*(f**2*(4*Pk*(4*sigma**6 + 63*sigma**4 + 495*sigma**2 + 3780) + k1*(-2*Pkd*(2*sigma**6 + 48*sigma**4 + 450*sigma**2 + 2835) + Pkdd*k1*(2*sigma**6 + 20*sigma**4 + 135*sigma**2 + 630)))*(2*t**2 - 2*t + 1) - 2*f*fd*(1 - 2*t)**2*(60*Pk*(sigma**4 + 9*sigma**2 + 126) + k1*(-9*Pkd*(4*sigma**4 + 45*sigma**2 + 315) + Pkdd*k1*(2*sigma**6 + 16*sigma**4 + 90*sigma**2 + 315))) + f*sigma**2*(20*Pk*sigma**4*t**2*xb1 - 8*Pk*sigma**4*t**2*xbd1 - 20*Pk*sigma**4*t*xb1 + 12*Pk*sigma**4*t*xbd1 + 10*Pk*sigma**4*xb1 - 4*Pk*sigma**4*xbd1 + 132*Pk*sigma**2*t**2*xb1 - 24*Pk*sigma**2*t**2*xbd1 - 132*Pk*sigma**2*t*xb1 + 36*Pk*sigma**2*t*xbd1 + 66*Pk*sigma**2*xb1 - 12*Pk*sigma**2*xbd1 + 1440*Pk*t**2*xb1 - 1440*Pk*t**2*xbd1 - 1440*Pk*t*xb1 + 2160*Pk*t*xbd1 + 720*Pk*xb1 - 720*Pk*xbd1 - 8*Pkd*k1*sigma**4*t**2*xb1 + 8*Pkd*k1*sigma**4*t*xb1 - 4*Pkd*k1*sigma**4*xb1 - 96*Pkd*k1*sigma**2*t**2*xb1 + 60*Pkd*k1*sigma**2*t**2*xbd1 + 96*Pkd*k1*sigma**2*t*xb1 - 90*Pkd*k1*sigma**2*t*xbd1 - 48*Pkd*k1*sigma**2*xb1 + 30*Pkd*k1*sigma**2*xbd1 - 900*Pkd*k1*t**2*xb1 + 900*Pkd*k1*t**2*xbd1 + 900*Pkd*k1*t*xb1 - 1350*Pkd*k1*t*xbd1 - 450*Pkd*k1*xb1 + 450*Pkd*k1*xbd1 + 4*Pkdd*k1**2*sigma**4*t**2*xb1 - 8*Pkdd*k1**2*sigma**4*t**2*xbd1 - 4*Pkdd*k1**2*sigma**4*t*xb1 + 12*Pkdd*k1**2*sigma**4*t*xbd1 + 2*Pkdd*k1**2*sigma**4*xb1 - 4*Pkdd*k1**2*sigma**4*xbd1 + 30*Pkdd*k1**2*sigma**2*t**2*xb1 - 48*Pkdd*k1**2*sigma**2*t**2*xbd1 - 30*Pkdd*k1**2*sigma**2*t*xb1 + 72*Pkdd*k1**2*sigma**2*t*xbd1 + 15*Pkdd*k1**2*sigma**2*xb1 - 24*Pkdd*k1**2*sigma**2*xbd1 + 180*Pkdd*k1**2*t**2*xb1 - 180*Pkdd*k1**2*t**2*xbd1 - 180*Pkdd*k1**2*t*xb1 + 270*Pkdd*k1**2*t*xbd1 + 90*Pkdd*k1**2*xb1 - 90*Pkdd*k1**2*xbd1 + b1*(2*Pk*(5*sigma**4 + 33*sigma**2 + 360) + k1*(-2*Pkd*(2*sigma**4 + 24*sigma**2 + 225) + Pkdd*k1*(2*sigma**4 + 15*sigma**2 + 90)))*(2*t**2 - 2*t + 1) - 2*bd1*t*(2*t - 1)*(2*Pk*(sigma**4 + 3*sigma**2 + 180) + k1*(-15*Pkd*(sigma**2 + 15) + Pkdd*k1*(2*sigma**4 + 12*sigma**2 + 45)))) - sigma**2*(b1*(2*fd*(2*Pk*(sigma**4 + 3*sigma**2 + 180) + k1*(-15*Pkd*(sigma**2 + 15) + Pkdd*k1*(2*sigma**4 + 12*sigma**2 + 45)))*(2*t**2 - 3*t + 1) + k1*sigma**2*(2*Pkd*(xb1*(2*sigma**2 + 9)*(2*t**2 - 2*t + 1) + xbd1*(sigma**2 - 9)*(2*t**2 - 3*t + 1)) + Pkdd*k1*(-xb1*(sigma**2 + 18)*(2*t**2 - 2*t + 1) + 2*xbd1*(2*sigma**2 + 9)*(2*t**2 - 3*t + 1)))) + 2*t*xb1*(2*t - 1)*(bd1*k1*sigma**2*(Pkd*(sigma**2 - 9) + Pkdd*k1*(2*sigma**2 + 9)) + fd*(2*Pk*(sigma**4 + 3*sigma**2 + 180) + k1*(-15*Pkd*(sigma**2 + 15) + Pkdd*k1*(2*sigma**4 + 12*sigma**2 + 45)))))) - Ddd*(2*t**2 - 2*t + 1)*(b1*k1*sigma**4*xb1*(Pkd*(sigma**2 - 9) + Pkdd*k1*(2*sigma**2 + 9)) + f**2*(60*Pk*(sigma**4 + 9*sigma**2 + 126) + k1*(-9*Pkd*(4*sigma**4 + 45*sigma**2 + 315) + Pkdd*k1*(2*sigma**6 + 16*sigma**4 + 90*sigma**2 + 315))) + f*sigma**2*(b1 + xb1)*(2*Pk*(sigma**4 + 3*sigma**2 + 180) + k1*(-15*Pkd*(sigma**2 + 15) + Pkdd*k1*(2*sigma**4 + 12*sigma**2 + 45))))) - 2*Dd**2*t*(t - 1)*(b1*k1*sigma**4*xb1*(Pkd*(sigma**2 - 9) + Pkdd*k1*(2*sigma**2 + 9)) + f**2*(60*Pk*(sigma**4 + 9*sigma**2 + 126) + k1*(-9*Pkd*(4*sigma**4 + 45*sigma**2 + 315) + Pkdd*k1*(2*sigma**6 + 16*sigma**4 + 90*sigma**2 + 315))) + f*sigma**2*(b1 + xb1)*(2*Pk*(sigma**4 + 3*sigma**2 + 180) + k1*(-15*Pkd*(sigma**2 + 15) + Pkdd*k1*(2*sigma**4 + 12*sigma**2 + 45))))) + 5*np.sqrt(2)*np.sqrt(np.pi)*(D1**2*(-b1*sigma**2*(t - 1)**2*(fd*(2*Pk*(sigma**6 - 10*sigma**4 + 87*sigma**2 - 360) + k1*(2*Pkd*(4*sigma**4 - 51*sigma**2 + 225) - Pkdd*k1*(sigma**4 - 15*sigma**2 + 90))) + fdd*(-2*Pk*(sigma**6 - 8*sigma**4 + 57*sigma**2 - 180) + k1*(-5*Pkd*(sigma**4 - 12*sigma**2 + 45) - 3*Pkdd*k1*(sigma**2 - 15))) - k1*sigma**2*(2*Pkd*xbd1*(sigma**2 - 9) + Pkd*xbdd1*(sigma**4 - 4*sigma**2 + 9) + Pkdd*k1*xbd1*(sigma**4 - 5*sigma**2 + 18) + Pkdd*k1*xbdd1*(sigma**2 - 9))) + f*(-3*fd*(4*Pk*(sigma**6 - 22*sigma**4 + 255*sigma**2 - 1260) + k1*(2*Pkd*(8*sigma**4 - 165*sigma**2 + 945) - Pkdd*k1*(sigma**4 - 25*sigma**2 + 210)))*(2*t**2 - 2*t + 1) + 3*fdd*(4*Pk*(sigma**6 - 18*sigma**4 + 165*sigma**2 - 630) + k1*(9*Pkd*(sigma**4 - 20*sigma**2 + 105) + 5*Pkdd*k1*(sigma**2 - 21)))*(2*t**2 - 2*t + 1) + sigma**2*(bd1*t**2*(-2*Pk*(sigma**6 - 10*sigma**4 + 87*sigma**2 - 360) + k1*(-2*Pkd*(4*sigma**4 - 51*sigma**2 + 225) + Pkdd*k1*(sigma**4 - 15*sigma**2 + 90))) + bdd1*t**2*(2*Pk*(sigma**6 - 8*sigma**4 + 57*sigma**2 - 180) + k1*(5*Pkd*(sigma**4 - 12*sigma**2 + 45) + 3*Pkdd*k1*(sigma**2 - 15))) - (t - 1)**2*(2*Pk*(xbd1*(sigma**6 - 10*sigma**4 + 87*sigma**2 - 360) - xbdd1*(sigma**6 - 8*sigma**4 + 57*sigma**2 - 180)) - k1*(-2*Pkd*xbd1*(4*sigma**4 - 51*sigma**2 + 225) + 5*Pkd*xbdd1*(sigma**4 - 12*sigma**2 + 45) + Pkdd*k1*xbd1*(sigma**4 - 15*sigma**2 + 90) + 3*Pkdd*k1*xbdd1*(sigma**2 - 15))))) + t*(6*fd**2*(t - 1)*(4*Pk*(sigma**6 - 18*sigma**4 + 165*sigma**2 - 630) + k1*(9*Pkd*(sigma**4 - 20*sigma**2 + 105) + 5*Pkdd*k1*(sigma**2 - 21))) + fd*sigma**2*(-2*Pk*(t*xb1*(sigma**6 - 10*sigma**4 + 87*sigma**2 - 360) - 2*t*xbd1*(sigma**6 - 8*sigma**4 + 57*sigma**2 - 180) + 2*xbd1*(sigma**6 - 8*sigma**4 + 57*sigma**2 - 180)) + 2*bd1*(t - 1)*(2*Pk*(sigma**6 - 8*sigma**4 + 57*sigma**2 - 180) + k1*(5*Pkd*(sigma**4 - 12*sigma**2 + 45) + 3*Pkdd*k1*(sigma**2 - 15))) + k1*(-2*Pkd*(t*xb1*(4*sigma**4 - 51*sigma**2 + 225) - 5*t*xbd1*(sigma**4 - 12*sigma**2 + 45) + 5*xbd1*(sigma**4 - 12*sigma**2 + 45)) + Pkdd*k1*(t*xb1*(sigma**4 - 15*sigma**2 + 90) + 6*t*xbd1*(sigma**2 - 15) - 6*xbd1*(sigma**2 - 15)))) + fdd*sigma**2*t*xb1*(2*Pk*(sigma**6 - 8*sigma**4 + 57*sigma**2 - 180) + k1*(5*Pkd*(sigma**4 - 12*sigma**2 + 45) + 3*Pkdd*k1*(sigma**2 - 15))) + k1*sigma**4*(bd1*(2*Pkd*(t*xb1*(sigma**2 - 9) + t*xbd1*(sigma**4 - 4*sigma**2 + 9) - xbd1*(sigma**4 - 4*sigma**2 + 9)) + Pkdd*k1*(t*xb1*(sigma**4 - 5*sigma**2 + 18) + 2*t*xbd1*(sigma**2 - 9) - 2*xbd1*(sigma**2 - 9))) + bdd1*t*xb1*(Pkd*(sigma**4 - 4*sigma**2 + 9) + Pkdd*k1*(sigma**2 - 9))))) + D1*(Dd*(-3*f**2*(4*Pk*(sigma**6 - 22*sigma**4 + 255*sigma**2 - 1260) + k1*(2*Pkd*(8*sigma**4 - 165*sigma**2 + 945) - Pkdd*k1*(sigma**4 - 25*sigma**2 + 210)))*(2*t**2 - 2*t + 1) + f*(6*fd*(1 - 2*t)**2*(4*Pk*(sigma**6 - 18*sigma**4 + 165*sigma**2 - 630) + k1*(9*Pkd*(sigma**4 - 20*sigma**2 + 105) + 5*Pkdd*k1*(sigma**2 - 21))) + sigma**2*(-4*Pk*sigma**6*t**2*xb1 + 8*Pk*sigma**6*t**2*xbd1 + 4*Pk*sigma**6*t*xb1 - 12*Pk*sigma**6*t*xbd1 - 2*Pk*sigma**6*xb1 + 4*Pk*sigma**6*xbd1 + 40*Pk*sigma**4*t**2*xb1 - 64*Pk*sigma**4*t**2*xbd1 - 40*Pk*sigma**4*t*xb1 + 96*Pk*sigma**4*t*xbd1 + 20*Pk*sigma**4*xb1 - 32*Pk*sigma**4*xbd1 - 348*Pk*sigma**2*t**2*xb1 + 456*Pk*sigma**2*t**2*xbd1 + 348*Pk*sigma**2*t*xb1 - 684*Pk*sigma**2*t*xbd1 - 174*Pk*sigma**2*xb1 + 228*Pk*sigma**2*xbd1 + 1440*Pk*t**2*xb1 - 1440*Pk*t**2*xbd1 - 1440*Pk*t*xb1 + 2160*Pk*t*xbd1 + 720*Pk*xb1 - 720*Pk*xbd1 - 16*Pkd*k1*sigma**4*t**2*xb1 + 20*Pkd*k1*sigma**4*t**2*xbd1 + 16*Pkd*k1*sigma**4*t*xb1 - 30*Pkd*k1*sigma**4*t*xbd1 - 8*Pkd*k1*sigma**4*xb1 + 10*Pkd*k1*sigma**4*xbd1 + 204*Pkd*k1*sigma**2*t**2*xb1 - 240*Pkd*k1*sigma**2*t**2*xbd1 - 204*Pkd*k1*sigma**2*t*xb1 + 360*Pkd*k1*sigma**2*t*xbd1 + 102*Pkd*k1*sigma**2*xb1 - 120*Pkd*k1*sigma**2*xbd1 - 900*Pkd*k1*t**2*xb1 + 900*Pkd*k1*t**2*xbd1 + 900*Pkd*k1*t*xb1 - 1350*Pkd*k1*t*xbd1 - 450*Pkd*k1*xb1 + 450*Pkd*k1*xbd1 + 2*Pkdd*k1**2*sigma**4*t**2*xb1 - 2*Pkdd*k1**2*sigma**4*t*xb1 + Pkdd*k1**2*sigma**4*xb1 - 30*Pkdd*k1**2*sigma**2*t**2*xb1 + 12*Pkdd*k1**2*sigma**2*t**2*xbd1 + 30*Pkdd*k1**2*sigma**2*t*xb1 - 18*Pkdd*k1**2*sigma**2*t*xbd1 - 15*Pkdd*k1**2*sigma**2*xb1 + 6*Pkdd*k1**2*sigma**2*xbd1 + 180*Pkdd*k1**2*t**2*xb1 - 180*Pkdd*k1**2*t**2*xbd1 - 180*Pkdd*k1**2*t*xb1 + 270*Pkdd*k1**2*t*xbd1 + 90*Pkdd*k1**2*xb1 - 90*Pkdd*k1**2*xbd1 - b1*(2*Pk*(sigma**6 - 10*sigma**4 + 87*sigma**2 - 360) + k1*(2*Pkd*(4*sigma**4 - 51*sigma**2 + 225) - Pkdd*k1*(sigma**4 - 15*sigma**2 + 90)))*(2*t**2 - 2*t + 1) + 2*bd1*t*(2*t - 1)*(2*Pk*(sigma**6 - 8*sigma**4 + 57*sigma**2 - 180) + k1*(5*Pkd*(sigma**4 - 12*sigma**2 + 45) + 3*Pkdd*k1*(sigma**2 - 15))))) + sigma**2*(b1*(2*fd*(2*Pk*(sigma**6 - 8*sigma**4 + 57*sigma**2 - 180) + k1*(5*Pkd*(sigma**4 - 12*sigma**2 + 45) + 3*Pkdd*k1*(sigma**2 - 15)))*(2*t**2 - 3*t + 1) + k1*sigma**2*(2*Pkd*(xb1*(sigma**2 - 9)*(2*t**2 - 2*t + 1) + xbd1*(sigma**4 - 4*sigma**2 + 9)*(2*t**2 - 3*t + 1)) + Pkdd*k1*(xb1*(sigma**4 - 5*sigma**2 + 18)*(2*t**2 - 2*t + 1) + 2*xbd1*(sigma**2 - 9)*(2*t**2 - 3*t + 1)))) + 2*t*xb1*(2*t - 1)*(bd1*k1*sigma**2*(Pkd*(sigma**4 - 4*sigma**2 + 9) + Pkdd*k1*(sigma**2 - 9)) + fd*(2*Pk*(sigma**6 - 8*sigma**4 + 57*sigma**2 - 180) + k1*(5*Pkd*(sigma**4 - 12*sigma**2 + 45) + 3*Pkdd*k1*(sigma**2 - 15)))))) + Ddd*(2*t**2 - 2*t + 1)*(b1*k1*sigma**4*xb1*(Pkd*(sigma**4 - 4*sigma**2 + 9) + Pkdd*k1*(sigma**2 - 9)) + 3*f**2*(4*Pk*(sigma**6 - 18*sigma**4 + 165*sigma**2 - 630) + k1*(9*Pkd*(sigma**4 - 20*sigma**2 + 105) + 5*Pkdd*k1*(sigma**2 - 21))) + f*sigma**2*(b1 + xb1)*(2*Pk*(sigma**6 - 8*sigma**4 + 57*sigma**2 - 180) + k1*(5*Pkd*(sigma**4 - 12*sigma**2 + 45) + 3*Pkdd*k1*(sigma**2 - 15))))) + 2*Dd**2*t*(t - 1)*(b1*k1*sigma**4*xb1*(Pkd*(sigma**4 - 4*sigma**2 + 9) + Pkdd*k1*(sigma**2 - 9)) + 3*f**2*(4*Pk*(sigma**6 - 18*sigma**4 + 165*sigma**2 - 630) + k1*(9*Pkd*(sigma**4 - 20*sigma**2 + 105) + 5*Pkdd*k1*(sigma**2 - 21))) + f*sigma**2*(b1 + xb1)*(2*Pk*(sigma**6 - 8*sigma**4 + 57*sigma**2 - 180) + k1*(5*Pkd*(sigma**4 - 12*sigma**2 + 45) + 3*Pkdd*k1*(sigma**2 - 15)))))*Erf(np.sqrt(2)*sigma/2)*np.exp(sigma**2/2))*np.exp(-sigma**2/2)/(8*d**2*k1**2*sigma**9)
        
        return expr
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    